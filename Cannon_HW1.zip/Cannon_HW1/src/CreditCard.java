import java.util.ArrayList;
import java.util.Collections;

/**
 * Class that validates credit card numbers.
 *   @author Caleb Cannon
 *   @version 1/27/24
 */

public class CreditCard{
	
	/**
	 * Array lists to keep track of credit card numbers.
	 */
	
	private ArrayList<String> validNums = new ArrayList<>();
	private ArrayList<String> invalidNums = new ArrayList<>();
	private ArrayList<String> corruptedNums = new ArrayList<>();
	private ArrayList<String> cardsList;
	
	
	/**
	 * CreditCard constructor, no parameters.
	 */
	
	public CreditCard() {
		this.cardsList = new ArrayList<>();
	}
	
	/**
	 * CreditCard constructor, intializes cardsList.
	 * @param ArrayList of credit card numbers.
	 */
	
	public CreditCard(ArrayList<String> cardsList) {
		this.cardsList = cardsList;
	}
	
	/**
	 * Method to check if credit card numbers are valid, using the findnums helper methods.
	 */
	
	public void isValid() {
		boolean question = false;
		for (String card: cardsList) {
			for(int i = 0; i < card.length(); i++) {
				if(card.charAt(i) == '?') {
					question = true;
					corruptedNums.add(card);
					break;
				}
			}
			if (question == false) {
				boolean result = luhnFormula(card);
				if (result == true) {
					validNums.add(card);
				}
				else {
					invalidNums.add(card);
				}
			}
		}
		findNums();
		}
	
	/**
	 * Method that specifically takes corrupted numbers and finds the proper digit.
	 */
	
	private void findNums() {
		for(String card: corruptedNums) {
			int trialNumber = 0;
			int questions = 0;
			for(int i = 0; i < card.length(); i++) {
				if(card.charAt(i) == '?') {
					questions += 1;
				}
			}
			if(questions < 2) {
				int index = card.indexOf('?');
				String trialCard = card.substring(0, index) + trialNumber + card.substring(index + 1);
				boolean result = luhnFormula(trialCard);
				while (result != true) {
					trialNumber += 1;
					trialCard = card.substring(0, index) + trialNumber + card.substring(index + 1);
					result = luhnFormula(trialCard);
					}
				validNums.add(trialCard);
				}
			else {
				invalidNums.add(card);
				}
			}
	}
	
	/**
	   * Uses the Luhn Formula to calculate a checksum (total).
	   * @param a single card number passed from the isValid or findNums method.
	   * @return boolean value back to isValid and findNums method.
	   */
	
	private boolean luhnFormula(String card) {
			int total = 0;
			int loopTotal = 0;
			for(int i = card.length() - 1; i >= 0; i--) {
				loopTotal += 1;
				int newNum = Character.getNumericValue(card.charAt(i));
				if(loopTotal % 2 == 0) {
					int temp =  newNum * 2;
					if (temp >= 10) {
						String overTen = Integer.toString(temp);
						for(int j = 0; j < overTen.length(); j++) {
							int splitNum = Character.getNumericValue(overTen.charAt(j));
							total += splitNum;
						}
					}
					else {
						total += temp;
					}
				}
				else {
					total += newNum;
				}
			}
			if (total % 10 == 0) {
				return true;
			}
			else {
				return false;
			}
	}
	
	/**
	   * Simple method to print out the final results in the specified format using collections.
	   */
	
	public void printList() {
		System.out.println("VALID");
		Collections.sort(validNums);
		for(int i = 0; i < validNums.size(); i++) {
			System.out.println(validNums.get(i));
		}
		Collections.sort(invalidNums);
		System.out.println("\nINVALID");
		for(int i = 0; i <  invalidNums.size(); i++) {
			System.out.println(invalidNums.get(i));
		}
	}

	
}

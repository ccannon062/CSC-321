
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Driver code for CreditCard class.
 *   @author Caleb Cannon
 *   @version 1/15/27
 */

public class Main {
	
	/**
	 * ArrayList to store cards from file input.
	 */
	
	private static ArrayList<String> cardNums = new ArrayList<>();
	
	/**
	 * Driver code. 
	 * Opens a user inputted file and passes information to CreditCards class via ArrayList format.
	 */
	
	public static void main(String args[]) {
		
		System.out.println("Please enter a file name: ");
		Scanner userInput = new Scanner(System.in);
		String filename = userInput.nextLine();

		try {
			Scanner scanner = new Scanner(new File(filename));
				
			while(scanner.hasNextLine()) {
				String line = scanner.nextLine();
				line = line.replaceAll(" ", "");
				line = line.replaceAll("-", "");
				cardNums.add(line);
			}
		}
		catch(FileNotFoundException e) {
			System.out.println("Sorry, but your file was not available.");
			}
		
		CreditCard cards = new CreditCard(cardNums);
		cards.isValid();
		cards.printList();
		userInput.close();
		}
	}
